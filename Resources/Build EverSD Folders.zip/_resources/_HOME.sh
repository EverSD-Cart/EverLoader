#!/bin/bash -x

SCRIPT_DIR=$(dirname "$BASH_SOURCE")
slot=${SCRIPT_DIR%????????}

if [ "$(cat /etc/rootfs_version | grep -i VS)" ]; then
  if test -f "/tmp/customtheme/images/cobalt/cobalt1080_main_Background.png.bak"; then
#    cp -rf /tmp/customtheme/images/cobalt/cobalt1080_main_Background.png.bak /tmp/customtheme/images/cobalt/cobalt1080_main_Background.png
    cp -rf /opt/menu/menu2.0/customtheme/images/cobalt/cobalt1080_main_Background.png /tmp/customtheme/images/cobalt/cobalt1080_main_Background.png
    cp -rf /tmp/customtheme/images/cobalt/cobalt1080_main_BottomBar_GradientFade_space.png.bak /tmp/customtheme/images/cobalt/cobalt1080_main_BottomBar_GradientFade_space.png
  fi
  killall -9 evercade_menu_cobalt
else
  if test -f "/tmp/customtheme/images/neon/neonHandheld_main_Background.png.bak"; then
#    cp -rf /tmp/customtheme/images/neon/neonHandheld_main_Background.png.bak /tmp/customtheme/images/neon/neonHandheld_main_Background.png
#    cp -rf /tmp/customtheme/images/neon/neon720_main_Background.png.bak /tmp/customtheme/images/neon/neon720_main_Background.png
    cp -rf /opt/menu/menu2.0/customtheme/images/cobalt/neonHandheld_main_Background.png /tmp/customtheme/images/neon/neonHandheld_main_Background.png
    cp -rf /opt/menu/menu2.0/customtheme/images/cobalt/neon720_main_Background.png /tmp/customtheme/images/neon/neon720_main_Background.png
  fi
  killItWithFire
fi

umount -l /mnt$slot
mount $slot/ /mnt$slot

if [ "$(cat /etc/rootfs_version | grep -i VS)" ]; then
  cd "/opt/menu/menu2.0/"
  ./evercade_menu_cobalt
else
  gameOn
fi
