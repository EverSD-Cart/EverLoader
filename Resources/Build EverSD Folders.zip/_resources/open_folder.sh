#!/bin/bash -x

SCRIPT=$(basename $BASH_SOURCE)
self=${SCRIPT%???}
self=${self#?}
SCRIPT_DIR=$(dirname "$BASH_SOURCE")
slot=${SCRIPT_DIR%????????}
if [ $slot = "/sdcard" ]; then DEVICE=mmcblk0p1; fi
if [ $slot = "/sdcard2" ]; then DEVICE=mmcblk1p1; fi

if test -f "$slot/game/legal_support.png"; then
  cp -rf $slot/game/legal_support.png $slot/folders/$self/game/legal_support.png
fi

if [ "$(cat /etc/rootfs_version | grep -i VS)" ]; then
  if test -f "$slot/folders/$self/wallpaper.png"; then
    cp -rf /tmp/customtheme/images/cobalt/cobalt1080_main_Background.png /tmp/customtheme/images/cobalt/cobalt1080_main_Background.png.bak
    cp -rf /tmp/customtheme/images/cobalt/cobalt1080_main_BottomBar_GradientFade_space.png /tmp/customtheme/images/cobalt/cobalt1080_main_BottomBar_GradientFade_space.png.bak
    cp -rf $slot/folders/$self/wallpaper.png /tmp/customtheme/images/cobalt/cobalt1080_main_Background.png
    cp -rf $slot/folders/bottomfade.png /tmp/customtheme/images/cobalt/cobalt1080_main_BottomBar_GradientFade_space.png
  fi
  killall -9 evercade_menu_cobalt
else
  if test -f "$slot/folders/$self/wallpaper272.png"; then
    cp -rf /tmp/customtheme/images/neon/neonHandheld_main_Background.png /tmp/customtheme/images/neon/neonHandheld_main_Background.png.bak
    cp -rf /tmp/customtheme/images/neon/neon720_main_Background.png /tmp/customtheme/images/neon/neon720_main_Background.png.bak
    cp -rf $slot/folders/$self/wallpaper272.png /tmp/customtheme/images/neon/neonHandheld_main_Background.png
    cp -rf $slot/folders/$self/wallpaper720.png /tmp/customtheme/images/neon/neon720_main_Background.png
  fi
  killItWithFire
fi

mkdir -p /tmp/sdcard
mkdir -p /tmp/sdcard2
mount -t vfat "/dev/$DEVICE" "/tmp/$slot"
mount "$slot/folders/$self" "$slot"
mount --bind "/tmp$slot/retroarch" "$slot/retroarch"
# mount --bind "/tmp$slot/roms" "$slot/roms"

if [ "$(cat /etc/rootfs_version | grep -i VS)" ]; then
  cd "/opt/menu/menu2.0/"
  ./evercade_menu_cobalt
else
  gameOn
fi